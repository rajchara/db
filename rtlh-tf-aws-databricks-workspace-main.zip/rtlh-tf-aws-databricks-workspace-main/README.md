# Databricks Workspace Deployment using Terraform

This repository is a template for deploying a Databricks workspace using Terraform. 
It includes three main Terraform modules and a GitHub Actions workflow for automated deployment.

## Terraform Modules

### 1. VPC Endpoints
This module sets up the necessary VPC endpoints and Databricks resources required for the Databricks workspace.
These resources are deployed ONCE per AWS account. If an account is hosting multiple workspaces, the VPC Endpoints resources will be shared.

### 2. Workspace Bucket
This module creates an S3 bucket that is used by the Databricks workspace for storage purposes.
The bucket is used to store logs and cache files for Databricks. 
This bucket will be deployed to a *different* AWS account to the one hosting Databricks. 
It will be deployed to the Lakehouse shared account instead.

### 3. Workspace
This module is responsible for creating and configuring the Databricks workspace.
It includes AWS resources such as security groups, IAM roles and policies. 
Additionally, it deploys Databricks resources using the Databricks mws provider.

Reference: https://registry.terraform.io/providers/databricks/databricks/latest/docs/guides/aws-private-link-workspace


## Deployment using GitHub Actions

The deployment process is automated using GitHub Actions, which are defined in the `.github` folder of this repository.
Below is the high-level deployment process:

1. Repo setup and configuration. Users will specify variables required for deployment.
2. Terraform planning. This will deploy required resources (VPC endpoints and S3 bucket), and then plan the workspace deployment
3. The plan result is displayed to a PR, where users can approve.
4. Once the PR is approved and merged, the Terraform apply step will run. The workspace will be deployed to the target account.

## Creating a workspace
1. Create new repo with "rtlh-tf-aws-databricks-workspace" as template
2. Setup "DATABRICKS_CLIENT_ID" and "DATABRICKS_CLIENT_SECRET" repo secrets
3. Create "dev", "test" and "prod" github actions environments
4. Deploy Github actions integration job from target account to repo. Call the role "AWS_TARGET_ACCOUNT_ROLE_ARN". Save as Github Environment variable for "dev" environment
5. Create a new Github Environment variable for "dev" environment called "TERRAFORM_VAR_FILE_PATH". Call it "environments/dev.tfvars"
6. Create a new Github Environment variable for "dev" environment called "TERRAFORM_WORKSPACE_NAME". Give it the workspace name of choice. Name convention is "<ACCOUNT_NUMBER>-ws-<BU>-<TEAM>-AWS-<syd/can>-<ENV>"
7. Create a new Github Environment variable for "dev" environment called "DATABRICKS_ACCOUNT_ID". Fill in the Databricks account ID to deploy the workspace to.
8. Create a new Github Environment variable for "dev" environment called "AWS_TARGET_ACCOUNT_ID". Fill in the AWS Account ID to deploy the workspace to.
9. Deploy Github actions integration job from lakehouse-shared account to repo. Call the role "AWS_LAKEHOUSE_SHARED_ROLE_ARN"
10. Clone the repo
11. Create new branch
12. Fill out "environments/dev.tfvars" file
13. Create PR to develop branch
14. Action will automatically run to deploy workspace

## Requirements

- Terraform v1.10 or later
- AWS account with necessary permissions
- GitHub account
